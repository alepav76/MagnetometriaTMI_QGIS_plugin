# -*- coding: utf-8 -*-
def classFactory(iface):
    from .magnetometria_tmi import MagnetometriaTMI
    return MagnetometriaTMI(iface)
