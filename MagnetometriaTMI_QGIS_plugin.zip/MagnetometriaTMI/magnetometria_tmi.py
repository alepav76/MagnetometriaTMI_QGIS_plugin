# -*- coding: utf-8 -*-
"""
Plugin QGIS: Elaborazione Magnetometrica TMI
Compatibilità prevista: QGIS 3.44.x / Python 3.12.
"""
import os
import gc
import uuid
import numpy as np

from osgeo import gdal
from scipy.ndimage import distance_transform_edt

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QProgressBar, QPlainTextEdit,
    QMessageBox, QGroupBox, QFormLayout, QCheckBox
)
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsCoordinateReferenceSystem
)


class MagnetometriaTMI:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction("Elaborazione Magnetometrica TMI", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Magnetometria TMI", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&Magnetometria TMI", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Elaborazione Magnetometrica TMI")
        dlg.setMinimumWidth(660)
        layout = QVBoxLayout(dlg)

        intro = QLabel(
            "Calcola le derivate X/Y, la derivata verticale tramite FFT, "
            "il gradiente orizzontale e il Segnale Analitico (AS)."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        group = QGroupBox("Dati di input e destinazione")
        form = QFormLayout(group)

        self.input_edit = QLineEdit()
        self.input_edit.setPlaceholderText("Seleziona un raster GeoTIFF o un raster GDAL valido")
        input_row = QHBoxLayout()
        input_row.addWidget(self.input_edit)
        input_btn = QPushButton("Sfoglia…")
        input_btn.clicked.connect(self._browse_input)
        input_row.addWidget(input_btn)
        form.addRow("Raster TMI:", input_row)

        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText("Seleziona la cartella in cui salvare i risultati")
        output_row = QHBoxLayout()
        output_row.addWidget(self.output_edit)
        output_btn = QPushButton("Sfoglia…")
        output_btn.clicked.connect(self._browse_output)
        output_row.addWidget(output_btn)
        form.addRow("Cartella output:", output_row)

        self.load_check = QCheckBox("Carica i raster prodotti nel progetto QGIS")
        self.load_check.setChecked(True)
        form.addRow("", self.load_check)

        layout.addWidget(group)

        note = QLabel(
            "Il raster deve essere su griglia regolare e in un CRS proiettato con unità "
            "lineari. La derivata verticale FFT è sensibile ai bordi e al rumore; "
            "vengono applicati padding riflesso e maschera dei bordi/NoData."
        )
        note.setWordWrap(True)
        layout.addWidget(note)

        self.progress = QProgressBar()
        self.progress.setRange(0, 5)
        self.progress.setValue(0)
        layout.addWidget(self.progress)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(500)
        self.log.setPlaceholderText("Messaggi dell'elaborazione…")
        layout.addWidget(self.log)

        buttons = QHBoxLayout()
        self.run_btn = QPushButton("Avvia elaborazione")
        self.run_btn.clicked.connect(self._execute)
        close_btn = QPushButton("Chiudi")
        close_btn.clicked.connect(dlg.close)
        buttons.addWidget(self.run_btn)
        buttons.addStretch(1)
        buttons.addWidget(close_btn)
        layout.addLayout(buttons)

        self.dialog = dlg
        dlg.exec_()
        self.dialog = None

    def _browse_input(self):
        path, _ = QFileDialog.getOpenFileName(
            self.dialog,
            "Seleziona raster TMI",
            "",
            "Raster supportati (*.tif *.tiff *.vrt *.img *.asc);;Tutti i file (*.*)"
        )
        if path:
            self.input_edit.setText(path)

    def _browse_output(self):
        path = QFileDialog.getExistingDirectory(
            self.dialog, "Seleziona cartella di destinazione", ""
        )
        if path:
            self.output_edit.setText(path)

    def _log(self, message):
        if self.dialog:
            self.log.appendPlainText(str(message))
            self.iface.mainWindow().statusBar().showMessage(str(message), 5000)

    def _execute(self):
        src_path = self.input_edit.text().strip()
        out_dir = self.output_edit.text().strip()

        if not src_path:
            QMessageBox.warning(self.dialog, "Input mancante", "Seleziona il raster TMI di input.")
            return
        if not os.path.isfile(src_path):
            QMessageBox.warning(self.dialog, "Input non valido", "Il file di input non esiste o non è accessibile.")
            return
        if not out_dir:
            QMessageBox.warning(self.dialog, "Destinazione mancante", "Seleziona la cartella di destinazione.")
            return

        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception as exc:
            QMessageBox.critical(self.dialog, "Cartella non accessibile", str(exc))
            return

        self.run_btn.setEnabled(False)
        self.progress.setValue(0)
        self.log.clear()

        try:
            self._process(src_path, out_dir, self.load_check.isChecked())
            QMessageBox.information(
                self.dialog, "Elaborazione completata",
                "Elaborazione completata.\n\nRisultati salvati in:\n" + out_dir
            )
        except Exception as exc:
            self._log("ERRORE: " + str(exc))
            QMessageBox.critical(
                self.dialog, "Errore di elaborazione",
                str(exc) + "\n\nConsulta il registro nella finestra del plugin."
            )
        finally:
            self.run_btn.setEnabled(True)

    def _process(self, src_path, out_dir, load_outputs):
        nodata_out = -9999.0
        ds = gdal.Open(src_path, gdal.GA_ReadOnly)
        if ds is None:
            raise RuntimeError("GDAL non riesce ad aprire il raster: " + src_path)

        try:
            band = ds.GetRasterBand(1)
            tmi = band.ReadAsArray().astype(np.float64)
            gt = ds.GetGeoTransform()
            projection = ds.GetProjection()
            raster_x, raster_y = ds.RasterXSize, ds.RasterYSize

            dx, dy = abs(gt[1]), abs(gt[5])
            if dx == 0 or dy == 0:
                raise ValueError("Dimensione del pixel non valida.")
            if abs(gt[2]) > 1e-12 or abs(gt[4]) > 1e-12:
                raise ValueError("Il raster è ruotato/shearato. Riproiettalo su una griglia nord-sud regolare prima dell'elaborazione.")
            if not projection:
                raise ValueError("Il raster non ha un sistema di coordinate definito.")
            crs = QgsCoordinateReferenceSystem()
            crs.createFromWkt(projection)
            if not crs.isValid():
                raise ValueError("Il sistema di coordinate del raster non è riconosciuto da QGIS.")
            if crs.isGeographic():
                raise ValueError("Il raster usa coordinate geografiche (gradi). Riproiettalo in un CRS proiettato con unità lineari, preferibilmente metri.")
            if min(tmi.shape) < 3:
                raise ValueError("Raster troppo piccolo per calcolare le derivate.")

            nodata = band.GetNoDataValue()
            mask = np.isfinite(tmi)
            if nodata is not None:
                if np.isnan(nodata):
                    mask &= ~np.isnan(tmi)
                else:
                    mask &= (tmi != nodata)
            if not np.any(mask):
                raise ValueError("Il raster non contiene celle valide.")

            self._log("Raster: " + src_path)
            self._log(f"Dimensioni: {raster_x} x {raster_y}; pixel: X={dx}, Y={dy}")

            interior = np.zeros(mask.shape, dtype=bool)
            interior[1:-1, 1:-1] = (
                mask[1:-1, 1:-1] & mask[:-2, 1:-1] &
                mask[2:, 1:-1] & mask[1:-1, :-2] &
                mask[1:-1, 2:]
            )
            if not np.any(interior):
                raise ValueError("Non ci sono abbastanza celle valide contigue per calcolare le derivate.")

            # Riempimento temporaneo dei NoData col valore valido più vicino.
            indices = distance_transform_edt(
                ~mask, return_distances=False, return_indices=True
            )
            tmi_filled = tmi[tuple(indices)]

            # Derivate orizzontali. Le coordinate raster possono avere asse Y invertito:
            # la derivata segue la convenzione delle coordinate del dataset.
            dTdy, dTdx = np.gradient(tmi_filled, dy, dx)
            gh = np.sqrt(dTdx**2 + dTdy**2)

            # Derivata verticale spettrale. Padding riflesso riduce, ma non elimina,
            # gli artefatti dovuti all'assunzione di periodicità della FFT.
            ny, nx = tmi_filled.shape
            pad_y = min(max(16, int(round(ny * 0.10))), max(1, ny - 1))
            pad_x = min(max(16, int(round(nx * 0.10))), max(1, nx - 1))
            padded = np.pad(tmi_filled, ((pad_y, pad_y), (pad_x, pad_x)), mode="reflect")
            pny, pnx = padded.shape
            fx = np.fft.fftfreq(pnx, d=dx)
            fy = np.fft.fftfreq(pny, d=dy)
            FX, FY = np.meshgrid(fx, fy)
            K = 2.0 * np.pi * np.sqrt(FX**2 + FY**2)
            F = np.fft.fft2(padded)
            dTdz_padded = np.fft.ifft2(K * F).real
            dTdz = dTdz_padded[pad_y:pad_y + ny, pad_x:pad_x + nx]
            AS = np.sqrt(dTdx**2 + dTdy**2 + dTdz**2)

            # Esclude un margine più prudente e le celle adiacenti a NoData.
            valid_output = interior.copy()
            if min(ny, nx) > 8:
                valid_output[:2, :] = False
                valid_output[-2:, :] = False
                valid_output[:, :2] = False
                valid_output[:, -2:] = False
            for arr in (dTdx, dTdy, dTdz, gh, AS):
                arr[~valid_output] = np.nan

            self._log("Derivate X/Y, derivata verticale FFT, gradiente e AS calcolati.")
            self._log(f"AS minimo: {float(np.nanmin(AS))}")
            self._log(f"AS massimo: {float(np.nanmax(AS))}")
            self._log(f"Padding FFT riflesso: X={pad_x}, Y={pad_y} celle.")
        finally:
            ds = None
            band = None

        products = [
            ("TMI_derivata_X.tif", dTdx),
            ("TMI_derivata_Y.tif", dTdy),
            ("TMI_derivata_verticale_FFT.tif", dTdz),
            ("TMI_gradiente_orizzontale.tif", gh),
            ("TMI_segnale_analitico_AS.tif", AS),
        ]

        target_paths = {
            os.path.normcase(os.path.abspath(os.path.join(out_dir, name)))
            for name, _ in products
        }

        # Rimuove dal progetto i layer che puntano ai file da aggiornare.
        project = QgsProject.instance()
        for layer in list(project.mapLayers().values()):
            try:
                source = layer.source().split("|")[0]
                normalized = os.path.normcase(os.path.abspath(source))
                if normalized in target_paths:
                    project.removeMapLayer(layer.id())
            except Exception:
                pass

        gc.collect()

        for i, (filename, array) in enumerate(products, start=1):
            self._save_raster(
                filename, array, out_dir, raster_x, raster_y, gt, projection,
                nodata_out, load_outputs
            )
            self.progress.setValue(i)
            self._log(f"Completato {i}/5: {filename}")

        self._write_report(out_dir, src_path, gt, projection, raster_x, raster_y,
                           dx, dy, mask, products)
        self._log("Report tecnico salvato: report_elaborazione_TMI.txt")
        self._log("Tutti i raster sono stati esportati.")

    def _write_report(self, out_dir, src_path, gt, projection, width, height,
                      dx, dy, mask, products):
        crs = QgsCoordinateReferenceSystem()
        crs.createFromWkt(projection)
        report_path = os.path.join(out_dir, "report_elaborazione_TMI.txt")
        lines = [
            "REPORT DI ELABORAZIONE MAGNETOMETRICA TMI",
            "=" * 44,
            "Input: " + src_path,
            "Data/ora elaborazione: " + __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
            f"Dimensioni raster: {width} colonne x {height} righe",
            f"Pixel: dx={dx:g}, dy={dy:g} (unità del CRS)",
            "CRS: " + (crs.authid() or crs.description() or "non identificato"),
            "Trasformazione georeferenziazione: " + repr(tuple(gt)),
            f"Celle valide in input: {int(np.count_nonzero(mask))} / {mask.size}",
            "NoData output: -9999",
            "Compressione GeoTIFF: LZW; tipo dato: Float32",
            "Derivata verticale: operatore spettrale |k| via FFT 2D, con padding riflesso del 10% (minimo 16 celle, limitato alle dimensioni del raster).",
            "Maschera output: celle NoData/adiacenti a NoData e margine di bordo esclusi.",
            "Attenzione: le derivate amplificano il rumore; l'FFT resta sensibile alle condizioni ai bordi. Verificare i risultati su dati di controllo.",
            "Unità: unità dei valori TMI divise per l'unità lineare del CRS; verificare le unità del raster sorgente.",
            ""
        ]
        for filename, array in products:
            valid = np.isfinite(array)
            if np.any(valid):
                lines.append(f"{filename}: min={np.nanmin(array):.8g}; max={np.nanmax(array):.8g}; media={np.nanmean(array):.8g}; celle valide={int(valid.sum())}")
            else:
                lines.append(f"{filename}: nessuna cella valida")
        temp = report_path + ".tmp"
        with open(temp, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        os.replace(temp, report_path)

    def _save_raster(self, filename, array, out_dir, raster_x, raster_y,
                     gt, projection, nodata_out, load_output):
        path = os.path.join(out_dir, filename)
        temp_path = os.path.join(out_dir, "_tmp_" + uuid.uuid4().hex + ".tif")
        driver = gdal.GetDriverByName("GTiff")
        out = None

        try:
            out = driver.Create(
                temp_path, raster_x, raster_y, 1, gdal.GDT_Float32,
                options=["COMPRESS=LZW", "TILED=YES", "BIGTIFF=IF_SAFER"]
            )
            if out is None:
                raise RuntimeError("Impossibile creare il GeoTIFF temporaneo: " + temp_path)

            out.SetGeoTransform(gt)
            out.SetProjection(projection)
            band = out.GetRasterBand(1)
            band.SetNoDataValue(nodata_out)
            data = np.where(np.isfinite(array), array, nodata_out).astype(np.float32)
            band.WriteArray(data)
            band.FlushCache()
            out.FlushCache()
            band = None
            out = None
            gc.collect()

            if not os.path.isfile(temp_path) or os.path.getsize(temp_path) == 0:
                raise RuntimeError("File temporaneo non valido: " + temp_path)

            try:
                os.replace(temp_path, path)
            except PermissionError as exc:
                raise PermissionError(
                    "Accesso negato al file:\n" + path +
                    "\n\nIl file potrebbe essere aperto o bloccato da QGIS o da un altro "
                    "programma. Chiudi i layer che lo utilizzano e verifica i permessi "
                    "della cartella. Il file temporaneo è:\n" + temp_path
                ) from exc

            self._log("Creato: " + path)

            if load_output:
                layer_name = os.path.splitext(filename)[0]
                raster = QgsRasterLayer(path, layer_name)
                if not raster.isValid():
                    raise RuntimeError("GeoTIFF creato ma non valido in QGIS: " + path)
                QgsProject.instance().addMapLayer(raster)

        finally:
            out = None
            gc.collect()
            if os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    self._log("Attenzione: temporaneo da verificare: " + temp_path)
