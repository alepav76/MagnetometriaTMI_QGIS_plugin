# Elaborazione Magnetometrica TMI — plugin QGIS 1.1.0

## Compatibilità
Progettato per QGIS 3.44.x. Il metadata dichiara QGIS 3.28 come versione minima, ma la compatibilità effettiva va verificata nell'installazione in uso. Dipendenze: GDAL, NumPy e SciPy disponibili nell'ambiente Python di QGIS.

## Installazione
1. Estrai la cartella `MagnetometriaTMI` dallo ZIP.
2. Copia la cartella nella directory dei plugin del profilo QGIS, normalmente `%APPDATA%\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\` su Windows.
3. Riavvia QGIS.
4. Apri **Plugin > Gestisci e installa plugin… > Installati** e abilita **Elaborazione Magnetometrica TMI**.
5. Apri **Plugin > Magnetometria TMI > Elaborazione Magnetometrica TMI**.

## Uso
1. Seleziona il raster TMI di input.
2. Seleziona la cartella di destinazione.
3. Scegli se caricare automaticamente i risultati nel progetto QGIS.
4. Premi **Avvia elaborazione** e controlla il registro nella finestra.

## Output
- `TMI_derivata_X.tif` — derivata lungo X.
- `TMI_derivata_Y.tif` — derivata lungo Y.
- `TMI_derivata_verticale_FFT.tif` — derivata verticale stimata con operatore spettrale |k|.
- `TMI_gradiente_orizzontale.tif` — modulo del gradiente orizzontale.
- `TMI_segnale_analitico_AS.tif` — modulo calcolato da derivate X, Y e verticale.
- `report_elaborazione_TMI.txt` — riepilogo di input, CRS, risoluzione, parametri, statistiche e avvertenze.

I GeoTIFF sono Float32, compressi LZW, georeferenziati e usano -9999 come NoData.

## Controlli e limiti
- Il raster deve essere georeferenziato, avere CRS riconosciuto e usare un CRS proiettato con unità lineari; raster in gradi o ruotati vengono rifiutati.
- La griglia deve essere regolare e avere almeno 3 x 3 celle. Il raster deve contenere celle valide contigue.
- I NoData sono riempiti temporaneamente col valore valido più vicino per consentire i calcoli; le celle NoData, adiacenti a NoData e una fascia di bordo vengono escluse dagli output.
- La derivata verticale usa FFT 2D e padding riflesso (minimo 16 celle o 10% delle dimensioni, limitato alle dimensioni del raster) per attenuare gli artefatti ai bordi. Questo non li elimina completamente: la derivata è sensibile al rumore e alle condizioni ai bordi.
- Le unità delle derivate dipendono dalle unità del TMI e dalle unità lineari del CRS. Verificare le unità dei dati sorgente.
- Il Segnale Analitico aiuta a interpretare anomalie, ma non identifica da solo materiale, profondità o posizione esatta di un corpo ferromagnetico.
- Validare su dati di prova noti prima dell'uso operativo. Il plugin non è stato eseguito in questa fase dentro una sessione QGIS reale.

## Sovrascrittura
Ogni GeoTIFF viene scritto prima in un file temporaneo e poi rinominato. Se un output esistente è bloccato da QGIS o da un altro programma, chiudere il layer/applicazione che lo utilizza e riprovare.
